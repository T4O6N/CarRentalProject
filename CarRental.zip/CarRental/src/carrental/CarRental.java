
package carrental;

import com.formdev.flatlaf.FlatDarculaLaf;
import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatIntelliJLaf;
import com.formdev.flatlaf.FlatLightLaf;
import javax.swing.UIManager;

public class CarRental {

    public static void main(String[] args) {
        // TODO code application logic here
        int themeIndex = 2;
        try {
    if(themeIndex == 1){
    UIManager.setLookAndFeel(new FlatLightLaf());
    }else if(themeIndex == 2){
    UIManager.setLookAndFeel(new FlatDarkLaf());
    }else if(themeIndex == 3){
    UIManager.setLookAndFeel(new FlatIntelliJLaf());
    }else if(themeIndex == 4){
    UIManager.setLookAndFeel(new FlatDarculaLaf());
    }
} catch( Exception ex ) {
    System.err.println( "Failed to initialize LaF" );
}

    }
    
}
